import base64
import pathlib
import os
from template import edm_template_caas
from template_no_rsvp import edm_template_no_rsvp
from string import Template
# import requests


parent_path = str(pathlib.Path(__file__).parent)
def get_b64_img():
	get_files_img = list(os.walk(parent_path + "/imgs/caas/"))
	files_img = []
	for _, _, last in get_files_img:
			for file in last:
				files_img.append(file)

	assets = {}
	for file in files_img:
			file_name = file.split(".")
			with open(parent_path + "./imgs/caas/" + file, "rb") as image:
				image_base64 = base64.b64encode(image.read()).decode("utf-8")
				title_one_b64_img = f"data:image/{file_name[-1]};base64,{image_base64}"
				assets[file_name[0]] = title_one_b64_img
	
	return assets

# def check_assets_type(arg):
# 	if arg == "base64" or arg == "url":
# 		return arg
# 	else:
# 		print(f"{arg} not accepted !")
# 		return None

# def get_base64_req(url):
# 	b64_img = base64.b64encode(requests.get(url).content).decode("utf-8")
# 	return f"data:image/png;base64,{b64_img}"

def generate_html(item, assets):
	# if asset_type == "base64":
	# 	item.update({"date":  get_base64_req(item.get("date"))});
	
	edm_html = Template(edm_template_caas).safe_substitute(**assets)
	with open(parent_path + "/result/caas/" + item +".html", "w") as html:
		html.write(edm_html)
